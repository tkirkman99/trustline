/**
 * REST service implementations
 * 
 * @author tk
 *
 */
package com.ripple.trustline.web.service;