/**
 * Manager-layer implementations.
 * 
 * @author tk
 *
 */
package com.ripple.trustline.manager.service;