/**
 * 
 */
package com.ripple.trustline.manager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ripple.trustline.manager.api.ServerInfoManager;
import com.ripple.trustline.resource.ServerInfo;
import com.ripple.trustline.util.InitContext;

/**
 * @author tk
 *
 */
@Service
public class StandardServerInfoManager implements ServerInfoManager {
	
	@Autowired ServerInfo serverInfo;

	/* (non-Javadoc)
	 * @see com.ripple.trustline.manager.api.ServerInfoManager#nameMachine(java.lang.String)
	 */
	@Override
	public ServerInfo nameMachine(String name) {
		if (serverInfo == null) {
			serverInfo = InitContext.getContext().getBean(ServerInfo.class);
		}
		if (serverInfo.getMachine() == null) {
			serverInfo.setMachine(name);
		}
		return serverInfo;
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.manager.api.ServerInfoManager#namePort(java.lang.String)
	 */
	@Override
	public ServerInfo namePort(String port) {
		if (serverInfo == null) {
			serverInfo = InitContext.getContext().getBean(ServerInfo.class);
		}
		if (serverInfo.getPort() == null) {
			serverInfo.setPort(port);
		}
		return serverInfo;
	}

}
