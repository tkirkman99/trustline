/**
 * 
 */
package com.ripple.trustline.manager.api;

import com.ripple.trustline.resource.ServerInfo;

/**
 * Manager-layer APIs for informing the server about the trustline's "other party" server.
 * 
 * @author tk
 *
 */
public interface ServerInfoManager {
	
	ServerInfo nameMachine(String name);
	
	ServerInfo namePort(String port);
}
