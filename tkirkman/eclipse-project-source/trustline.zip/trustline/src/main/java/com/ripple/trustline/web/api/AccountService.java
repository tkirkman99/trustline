package com.ripple.trustline.web.api;

import java.math.BigDecimal;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.enunciate.jaxrs.ResponseCode;
import org.codehaus.enunciate.jaxrs.StatusCodes;

import com.ripple.trustline.resource.ReceivingAccount;
import com.ripple.trustline.resource.SendingAccount;
import com.ripple.trustline.web.exception.OperationFailedException;


/**
 * Manage trustline user account.
 * 
 * @author tk
 *
 */
@Path("/account")
public interface AccountService {
	
    /**
     * Name the user account.
     * 
     * @param name
     *        The name for the user account.
     *         
     * @return A response containing an HTTP status code.
     * @throws OperationFailedException
     */
    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @StatusCodes({ 
      @ResponseCode(code = 200, condition = "Updated"), 
      @ResponseCode(code = 400, condition = "Bad or malformed request."), 
      @ResponseCode(code = 404, condition = "Not Found.") 
    })
    @Path("/{name}")
	SendingAccount nameAccount(@PathParam("name") String name);

    /**
     * Debit the account's current balance.
     * 
     * @param amount
     *        The amount to be debited. 
     *         
     * @return A response containing an HTTP status code.
     * @throws OperationFailedException
     */
    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @StatusCodes({ 
      @ResponseCode(code = 200, condition = "Updated"), 
      @ResponseCode(code = 400, condition = "Bad or malformed request."), 
      @ResponseCode(code = 404, condition = "Not Found.") 
    })
    @Path("/debit/{amount}")
	List<String> debitAccount(@PathParam("amount") BigDecimal amount) throws OperationFailedException;
    
    /**
     * Credis the account's current balance.
     * 
     * @param amount
     *        The amount to be credited. 
     *         
     * @return A response containing an HTTP status code.
     * @throws OperationFailedException
     */
    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @StatusCodes({ 
      @ResponseCode(code = 200, condition = "Updated"), 
      @ResponseCode(code = 400, condition = "Bad or malformed request."), 
      @ResponseCode(code = 404, condition = "Not Found.") 
    })
    @Path("/credit/{amount}")
	ReceivingAccount creditAccount(@PathParam("amount") BigDecimal amount);
}
