/**
 * 
 */
package com.ripple.trustline.manager.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ripple.trustline.manager.api.AccountManager;
import com.ripple.trustline.resource.ReceivingAccount;
import com.ripple.trustline.resource.SendingAccount;
import com.ripple.trustline.resource.ServerInfo;
import com.ripple.trustline.web.exception.OperationFailedException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Implementation of user account management actions.
 * 
 * @author tk
 *
 */
@Service
public class StandardAccountManager implements AccountManager {
	
	private static final Object LOCK_OBJECT = new Object();
	
	@Resource(name="sendingAccount")
	SendingAccount sendingAccount;
	@Resource(name="receivingAccount")
	ReceivingAccount receivingAccount;
	@Resource(name="serverInfo")
	ServerInfo serverInfo;

	/* (non-Javadoc)
	 * @see com.ripple.trustline.manager.api.AccountManager#nameAccount(java.lang.String)
	 */
	@Override
	public SendingAccount nameAccount(String name) {
		if (sendingAccount.getName() == null) {
			sendingAccount.setName(name);
		}
		return sendingAccount;
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.manager.api.AccountManager#creditAccount(java.math.BigDecimal)
	 */
	@Override
	public ReceivingAccount creditAccount(BigDecimal amount) {
		synchronized(LOCK_OBJECT) {
			sendingAccount.setBalance(sendingAccount.getBalance().add(amount));
		}
		receivingAccount.setName(sendingAccount.getName());
		receivingAccount.setBalance(sendingAccount.getBalance());
		return receivingAccount;
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.manager.api.AccountManager#debitAccount(java.math.BigDecimal)
	 */
	@Override
	public List<String> debitAccount(BigDecimal amount) throws OperationFailedException {
		ReceivingAccount receivingAccount = null;
		try {
			Client client = Client.create();

			WebResource webResource = client.resource(
						"http://" +
						serverInfo.getMachine() + ":" +
						serverInfo.getPort() + 
						"/trustline/account/credit/" +
						amount);

			ClientResponse response = webResource.accept("application/json").put(ClientResponse.class);

			if (response.getStatus() != 200) {
			   throw new RuntimeException("Failed: HTTP error code: "
				+ response.getStatus());
			}

			receivingAccount = response.getEntity(ReceivingAccount.class);
			
		} catch (Exception e) {
			throw new OperationFailedException(e.getMessage());
		}
		synchronized(LOCK_OBJECT) {
			sendingAccount.setBalance(sendingAccount.getBalance().subtract(amount));
		}
		List<String> msgs = new ArrayList<String>();
		msgs.add(sendingAccount.getDebitMsg() + amount + " to " + receivingAccount.getName());
		msgs.add(sendingAccount.getBalanceMsg());
		msgs.add(receivingAccount.getCreditMsg() + amount);
		msgs.add(receivingAccount.getBalanceMsg());
		
		return msgs;
	}

}
