/**
 * Server Manager-Layer APIs
 * 
 * @author tk
 *
 */
package com.ripple.trustline.manager.api;