/**
 * Domain classes
 * 
 * @author tk
 *
 */
package com.ripple.trustline.resource;