/**
 * 
 */
package com.ripple.trustline.web.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.enunciate.jaxrs.ResponseCode;
import org.codehaus.enunciate.jaxrs.StatusCodes;

import com.ripple.trustline.resource.ServerInfo;

/**
 * Inform the sending server about the trustline's "other party" (receiving) server.
 * These APIs allow the sending server to be reconfigured at runtime to 
 * exchange debt with various receiving servers.  Receiving server Machine Name
 * and Machine Port can be set independently of one another.
 * 
 * @author tk
 *
 */
@Path("/info")
public interface ServerInfoService {

    /**
     * Names the trustline's "other party" server machine.
     * 
     * @param name
     *        The name of the machine the trustline's "other party" server process is running on.
     *         
     * @return A response containing an HTTP status code.
     * @throws OperationFailedException
     */
    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @StatusCodes({ 
      @ResponseCode(code = 200, condition = "Updated"), 
      @ResponseCode(code = 400, condition = "Bad or malformed request."), 
      @ResponseCode(code = 404, condition = "Not Found.") 
    })
    @Path("/machine/{name}")
	ServerInfo nameMachine(@PathParam("name") String name);

    /**
     * Names the trustline's "other party" server port.
     * 
     * @param name
     *        The name of the port the trustline's "other party" server process is running on.
     *         
     * @return A response containing an HTTP status code.
     * @throws OperationFailedException
     */
    @PUT
    @Produces({ MediaType.APPLICATION_JSON })
    @Consumes({ MediaType.APPLICATION_JSON })
    @StatusCodes({ 
      @ResponseCode(code = 200, condition = "Updated"), 
      @ResponseCode(code = 400, condition = "Bad or malformed request."), 
      @ResponseCode(code = 404, condition = "Not Found.") 
    })
    @Path("/port/{port}")
    ServerInfo namePort(@PathParam("port") String port);

}
