package com.ripple.trustline.web.api;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig;

import com.ripple.trustline.web.service.StandardAccountService;
import com.ripple.trustline.web.service.StandardServerInfoService;

/**
 * Initializing Jersey and providing package names that contain REST resources
 * 
 * @author tk
 *
 */
@ApplicationPath("/")
public class RestServices extends ResourceConfig {

    public RestServices() {
    	registerClasses(StandardAccountService.class);
    	registerClasses(StandardServerInfoService.class);
    }

}
