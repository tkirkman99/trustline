/**
 * Server utilities
 * 
 * @author tk
 *
 */
package com.ripple.trustline.util;