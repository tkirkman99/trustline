/**
 * 
 */
package com.ripple.trustline.resource;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Receiving user account information
 * @author tk
 *
 */
@Component
@Scope("singleton")
public class ReceivingAccount implements Serializable {

	/**
	 *  Generated
	 */
	private static final long serialVersionUID = 4312324860210761787L;
	
	private String name;
	private BigDecimal balance = new BigDecimal(0);
	private final String creditMsg = " was paid: $";
	private final String debitMsg = "Paying: ";
	private final String balanceMsg = "'s trustline balance is: $";

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public String getCreditMsg() {
		return getName() + creditMsg;
	}
	public String getDebitMsg() {
		return debitMsg;
	}
	public String getBalanceMsg() {
		return getName() + balanceMsg + getBalance();
	}
	
	@Override
	public String toString() {
		return "Name: " + getName() + ", Balance: " + getBalance();
	}


}
