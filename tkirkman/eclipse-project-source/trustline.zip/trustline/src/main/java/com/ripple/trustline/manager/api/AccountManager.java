/**
 * 
 */
package com.ripple.trustline.manager.api;

import java.math.BigDecimal;
import java.util.List;

import com.ripple.trustline.resource.ReceivingAccount;
import com.ripple.trustline.resource.SendingAccount;
import com.ripple.trustline.web.exception.OperationFailedException;

/**
 * Manager-layer APIs for managing a user account.
 * 
 * @author tk
 *
 */
public interface AccountManager {
	
	SendingAccount nameAccount(String name);
	
	ReceivingAccount creditAccount(BigDecimal amount);

	List<String> debitAccount(BigDecimal amount) throws OperationFailedException;
	
}
