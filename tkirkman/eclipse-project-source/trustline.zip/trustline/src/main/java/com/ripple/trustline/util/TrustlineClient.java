/**
 * 
 */
package com.ripple.trustline.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

/**
 * Trustline client application for sending debt to
 * a user account on a specified server.
 * 
 * @author tk
 *
 */
public class TrustlineClient {
	
	private static final String MACHINE = "localhost";
	private static final String SENDING_PORT = "8081";
	private static final String EXIT_COMMAND = "exit";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DefaultClientConfig defaultClientConfig = new DefaultClientConfig();
		defaultClientConfig.getClasses().add(JacksonJsonProvider.class);
		Client client = Client.create(defaultClientConfig);
		ClientResponse response = null;
		
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter a debt amount to send, or '" + EXIT_COMMAND + "' to quit");
        while (true) {
        	String input = null;
        	Double n;
			try {
				input = br.readLine();
		        if (input.length() == EXIT_COMMAND.length() && input.toLowerCase().equals(EXIT_COMMAND)) {
		            System.out.println("Exiting...");
		            System.exit(0);
		        }
				n = Double.parseDouble(input);
			    // Send the debt
	            response = callServer(client,
	         		   				 MACHINE,
	         		   				 SENDING_PORT,
	         		   				 "account/debit/",
	         		   				 String.valueOf(Math.abs(n)));
	            List<String> msgs = response.getEntity(new GenericType<List<String>>() {});
	            for (String s : msgs) {
	         	   System.out.println(s);
	            }
			} catch(NumberFormatException nfe) {
				System.out.println("Argument '" + input + "' is not a number."); 
			} catch (Exception e) {
				System.out.println(e.getMessage());
	            System.out.println("Exiting...");
	            System.exit(1);
			}
	    }
	}
	
	private static ClientResponse callServer(Client client,
											 String machine,
											 String port,
											 String path,
											 String pathParam) {
		ClientResponse response = null;
		WebResource webResource = client.resource(
						"http://" +
						machine + ":" +
						port + "/trustline/" +
						path +
						pathParam);

		response = webResource.accept("application/json").put(ClientResponse.class);

		if (response.getStatus() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
				+ response.getStatus());
		}
		return response;
	}

}
