/**
 * 
 */
package com.ripple.trustline.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

/**
 * @author tk
 *
 */
public class InitContext {

    public static ApplicationContext getContext() {
        return new GenericXmlApplicationContext("applicationContext.xml");
    }
}
