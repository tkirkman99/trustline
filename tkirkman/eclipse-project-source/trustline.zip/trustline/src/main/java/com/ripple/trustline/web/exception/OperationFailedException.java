package com.ripple.trustline.web.exception;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OperationFailedException extends Exception {
	
	/**
	 *  Generated
	 */
	private static final long serialVersionUID = -736965267140537951L;

	public OperationFailedException(String msg) {
		super(msg);
	}
}
