/**
 * 
 */
package com.ripple.trustline.util;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.DefaultClientConfig;

/**
 * Create user accounts and receiving server information
 * on the sending servers.
 * 
 * @author tk
 *
 */
public class ClientAccountSetup {

	private static final String MACHINE1 = "localhost";
	private static final String MACHINE2 = "localhost";
	private static final String PORT1 = "8080";
	private static final String PORT2 = "8081";
	private static final String ACCOUNT_NAME1 = "Fred";
	private static final String ACCOUNT_NAME2 = "Wilma";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DefaultClientConfig defaultClientConfig = new DefaultClientConfig();
		defaultClientConfig.getClasses().add(JacksonJsonProvider.class);
		Client client = Client.create(defaultClientConfig);
		ClientResponse response = null;
		
		// Server1:
		// Name the sending account
		response = callServer(client, MACHINE1, PORT1, "account/", ACCOUNT_NAME1);
		System.out.println("Server1: The Sending account is named: " + ACCOUNT_NAME1);
		// Name the receiving server & port
		response = callServer(client, MACHINE1, PORT1, "info/machine/", MACHINE2);
		response = callServer(client, MACHINE1, PORT1, "info/port/", PORT2);

		// Server2:
		// Name the sending account
		response = callServer(client, MACHINE2, PORT2, "account/", ACCOUNT_NAME2);
		System.out.println("Server2: The Sending account is named: " + ACCOUNT_NAME2);
		// Name the receiving server & port
		response = callServer(client, MACHINE2, PORT2, "info/machine/", MACHINE1);
		response = callServer(client, MACHINE2, PORT2, "info/port/", PORT1);
		System.out.println("Accounts setup completed.");
	}
	
	private static ClientResponse callServer(Client client,
											 String machine,
											 String port,
											 String path,
											 String pathParam) {
		ClientResponse response = null;
		WebResource webResource = client.resource(
						"http://" +
						machine + ":" +
						port + "/trustline/" +
						path +
						pathParam);

		response = webResource.accept("application/json").put(ClientResponse.class);

		if (response.getStatus() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ response.getStatus());
		}
		return response;
	}

}
