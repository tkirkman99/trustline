/**
 * 
 */
package com.ripple.trustline.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ripple.trustline.manager.api.ServerInfoManager;
import com.ripple.trustline.manager.service.StandardServerInfoManager;
import com.ripple.trustline.resource.ServerInfo;
import com.ripple.trustline.util.InitContext;
import com.ripple.trustline.web.api.ServerInfoService;

/**
 * @author tk
 *
 */
@Service
public class StandardServerInfoService implements ServerInfoService {
	
	@Autowired ServerInfoManager serverInfoManager;

	/* (non-Javadoc)
	 * @see com.ripple.trustline.web.api.ServerInfoService#nameMachine(java.lang.String)
	 */
	@Override
	public ServerInfo nameMachine(String name) {
		if (serverInfoManager == null) {
			serverInfoManager = InitContext.getContext().getBean(StandardServerInfoManager.class);
		}
		return serverInfoManager.nameMachine(name);
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.web.api.ServerInfoService#namePort(java.lang.String)
	 */
	@Override
	public ServerInfo namePort(String port) {
		if (serverInfoManager == null) {
			serverInfoManager = InitContext.getContext().getBean(StandardServerInfoManager.class);
		}
		return serverInfoManager.namePort(port);
	}

}
