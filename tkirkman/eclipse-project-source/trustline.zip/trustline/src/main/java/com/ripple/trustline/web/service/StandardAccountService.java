/**
 * 
 */
package com.ripple.trustline.web.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ripple.trustline.manager.api.AccountManager;
import com.ripple.trustline.manager.service.StandardAccountManager;
import com.ripple.trustline.resource.ReceivingAccount;
import com.ripple.trustline.resource.SendingAccount;
import com.ripple.trustline.util.InitContext;
import com.ripple.trustline.web.api.AccountService;
import com.ripple.trustline.web.exception.OperationFailedException;

/**
 * Implementation of user account management APIs
 * 
 * @author tk
 *
 */
@Service
public class StandardAccountService implements AccountService {
	
	@Autowired AccountManager accountManager;

	/* (non-Javadoc)
	 * @see com.ripple.trustline.web.api.AccountService#nameAccount(java.lang.String)
	 */
	@Override
	public SendingAccount nameAccount(String name) {
        if (accountManager == null) {
            accountManager = InitContext.getContext().getBean(StandardAccountManager.class);
        }
        return accountManager.nameAccount(name);
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.web.api.AccountService#debitAccount(java.math.BigDecimal)
	 */
	@Override
	public List<String> debitAccount(BigDecimal amount) throws OperationFailedException {
        if (accountManager == null) {
            accountManager = InitContext.getContext().getBean(StandardAccountManager.class);
        }
        return accountManager.debitAccount(amount);
	}

	/* (non-Javadoc)
	 * @see com.ripple.trustline.web.api.AccountService#creditAccount(java.math.BigDecimal)
	 */
	@Override
	public ReceivingAccount creditAccount(BigDecimal amount) {
        if (accountManager == null) {
            accountManager = InitContext.getContext().getBean(StandardAccountManager.class);
        }
        return accountManager.creditAccount(amount);
	}

}
