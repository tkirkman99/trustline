/**
 * 
 */
package com.ripple.trustline.resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author tk
 *
 */
@Component
@Scope("singleton")
public class ServerInfo {

	private static String machine;
	private static String port;
	
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		ServerInfo.machine = machine;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		ServerInfo.port = port;
	}
}
