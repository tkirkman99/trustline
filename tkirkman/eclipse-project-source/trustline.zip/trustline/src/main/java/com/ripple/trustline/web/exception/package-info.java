/**
 * HTTP exception wrappers
 * 
 * @author tk
 *
 */
package com.ripple.trustline.web.exception;